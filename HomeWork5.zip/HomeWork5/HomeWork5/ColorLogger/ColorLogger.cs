﻿using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace HomeWork5.ColorLogger
{
    public class ColorLogger : ILogger
    {
        public IDisposable BeginScope<TState>(TState state)
        {
            return null;
        }

        public bool IsEnabled(LogLevel logLevel)
        {
            return true;
        }

        public void Log<TState>(LogLevel logLevel, EventId eventId, TState state, Exception exception, Func<TState, Exception, string> formatter)
        {
            switch (logLevel)
            {
                case LogLevel.Trace:
                    Console.ForegroundColor = ConsoleColor.DarkBlue;
                    Console.WriteLine(LogLevel.Trace);
                    break;
                case LogLevel.Debug:
                    Console.ForegroundColor = ConsoleColor.DarkGreen;
                    Console.WriteLine(LogLevel.Debug);
                    break;
                case LogLevel.Information:
                    Console.ForegroundColor = ConsoleColor.DarkCyan;
                    Console.WriteLine(LogLevel.Information);
                    break;
                case LogLevel.Warning:
                    Console.ForegroundColor = ConsoleColor.DarkRed;
                    Console.WriteLine(LogLevel.Warning);
                    break;
                case LogLevel.Error:
                    Console.ForegroundColor = ConsoleColor.DarkMagenta;
                    Console.WriteLine(LogLevel.Error);
                    break;
                case LogLevel.Critical:
                    Console.ForegroundColor = ConsoleColor.DarkYellow;
                    Console.WriteLine(LogLevel.Critical);
                    break;
                case LogLevel.None:
                    Console.ForegroundColor = ConsoleColor.DarkGray;
                    Console.WriteLine(LogLevel.None);
                    break;
                default:
                    break;
            }
        }
    }
}

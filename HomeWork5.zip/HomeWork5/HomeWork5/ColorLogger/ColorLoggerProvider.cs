﻿using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace HomeWork5.ColorLogger
{
    [ProviderAlias("ColorLogger")]
    public class ColorLoggerProvider : ILoggerProvider
    {
        public ILogger CreateLogger(string categoryName)
        {
            return new ColorLogger();
        }

        public void Dispose()
        {
            
        }
    }
}
